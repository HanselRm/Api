﻿namespace WebApplication1.Models
{
    public class Estudiante
    {
        public String Matricula { get; set; }
        public String Nombre { get; set; }
        public String Apellido { get; set; }
        public DateTime FechaDeNacimiento { get; set; }
        public String Carrera { get; set; }
    }
}
